# H&S-restaurants

-Using C++ programming languages to developed an order processing system that includes functionality for taking meal orders and calculating quantities.
-Integrated checkout features to compute subtotals, apply sales tax, and calculate the total amount and change due.
-Added options such as generating sales reports and handling next customer interactions.
